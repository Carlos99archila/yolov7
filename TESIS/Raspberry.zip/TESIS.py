# proyectodetectorpeatones@gmail.com ProyectoIA@  alvarovargas1 --- 172.20.10.4 sudo rm -R /home/pi1/.local/share/Trash/files/* vaciar papelera reciclaje
# TF-HUB Module https://storage.googleapis.com/tfhub-modules/google/tf2-preview/mobilenet_v2/feature_vector/4.tar.gz
     
import time
import os
import cv2
camera = cv2.VideoCapture(0)
w=camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
h=camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
return_value, image = camera.read()
cv2.imwrite(f'yolov7/TESIS/exp/imagetesis.png', image)
del(camera)
os.system('cd /home/pi1/yolov7')
os.system(f'python yolov7/detect.py --classes 0 --weights yolov7-tiny.pt --conf 0.5 --img-size 640 --exist-ok --source yolov7/TESIS/exp/imagetesis.png')


